# a) Escribir un TAD ColaDePacientes, con los métodos nuevo_paciente, que recibe el nombre del paciente y lo
# encola, y un método proximo_paciente que devuelva el primer paciente en la cola y lo desencole.
# b) Escribir un TAD Recepción, que contenga un diccionario con las colas correspondientes a cada doctor o
# doctora, y los métodos nuevo_paciente que reciba el nombre del paciente y del especialista, y proximo_paciente
# que reciba el nombre de la persona liberada (el médico que terminó de atender) y devuelva el próximo paciente en
# espera (para ese médico). 


class ColaDePacientes:
    def __init__(self):
        self.items = []
    
    def estaVacia(self):
        if len(self.items) == 0:
            return True
        return False
    
    def nuevo_paciente(self, paciente):
        return self.items.append(paciente)
    
    def proximo_paciente(self):
        if self.estaVacia():
            raise IndexError("La cola esta vacía")
        return self.items.pop(0)

    def __str__(self):
        return str(self.items)  

class Recepcion:
    def __init__(self):
        self.colas = {}
    def nuevo_paciente(self, nombrePaciente, nombreEspecialista):
        if nombreEspecialista not in self.colas:
            self.colas[nombreEspecialista] = ColaDePacientes()
        return self.colas[nombreEspecialista].nuevo_paciente(nombrePaciente)
    def proximo_paciente(self, medicoLibre):
        if medicoLibre not in self.colas:
            raise KeyError("Entrada no encontrada")
        else:
            return self.colas[medicoLibre].proximo_paciente()


        